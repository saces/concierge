Building ConciergeLauncher from Source
--------------------------------------

Prerequisites
-------------

- UIQ3SDK
- all environment variables set correctly according to SDK instructions


Building the Launcher
---------------------

- open a command prompt
- run "create-ppro-app arm ConciergeLauncher E0000000 
       <full-path-to>\conciergelauncher.j9" (all in one line)
     ---> NOTE: you have to specify the full path to the file
- this will create a folder "PProLauncherE0000000" under
  "%EPOCROOT%\epoc32\tools\ppro-custom-launcher\output\arm"
  where %EPOCROOT% is the installation location of the SDK
- edit the file ending with .pkg if you wish to change the vendor
- run build-sis.bat to build the installation package




Tested with UIQ3 SDK "den 5 maj 2006 09:38:27" (version.txt in SDK root)


---
2007-04-03 Michael Duller